export { VueResolver as VueResolver } from "./vue-resolver";
